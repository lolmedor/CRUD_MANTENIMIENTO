class ModGrupo:
    def __init__(self, ind=0, desc=''):
        self.id=ind
        self.descripcion=desc

