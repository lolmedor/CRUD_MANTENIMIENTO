class ModPlancuenta:
    def __init__(self, ind=0, cod='', grup=0, desc='', natura='', est=0):
        self.id=ind
        self.codigo=cod
        self.grupo=grup
        self.descripcion=desc
        self.naturaleza=natura
        self.estado=est
